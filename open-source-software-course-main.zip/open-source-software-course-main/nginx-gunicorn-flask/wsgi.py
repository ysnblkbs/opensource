from myflaskservice import myflaskapp

if __name__ == "__main__":
    myflaskapp.run()
